make clean
make check TARGET=sw_emu DEVICE=$AWS_PLATFORM all
